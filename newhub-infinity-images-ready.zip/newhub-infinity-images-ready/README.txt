NewHub Infinity Canvas image pack

Contents:
- public/infinity-canvas/canvas-01.webp through canvas-24.webp
- src/components/landing/WhatIsNewHubSection.tsx

The 24 uploaded JPG images were renamed and converted to WebP for safer paths and smaller loading size.
This package assumes InfiniteGallery.tsx is already installed at:
src/components/landing/effects/InfiniteGallery.tsx

Copy the public folder into the landing app public folder and replace WhatIsNewHubSection.tsx.
