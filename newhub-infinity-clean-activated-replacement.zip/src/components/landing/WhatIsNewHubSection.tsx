import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  MousePointerClick,
  Move,
  Sparkles,
  X,
  ZoomIn,
} from "lucide-react";
import { BRAND_GRADIENT_TEXT } from "@/lib/brand";
import InfiniteGallery from "./effects/InfiniteGallery";

const newHubImages = [
  { src: "/infinity-canvas/canvas-01.webp", alt: "Your only limit is you" },
  { src: "/infinity-canvas/canvas-02.webp", alt: "Person walking through golden light" },
  { src: "/infinity-canvas/canvas-03.webp", alt: "Be the energy you want to attract" },
  { src: "/infinity-canvas/canvas-04.webp", alt: "Professional team celebrating together" },
  { src: "/infinity-canvas/canvas-05.webp", alt: "Community over competition" },
  { src: "/infinity-canvas/canvas-06.webp", alt: "Personal identity and self connection" },
  { src: "/infinity-canvas/canvas-07.webp", alt: "Diverse team celebrating" },
  { src: "/infinity-canvas/canvas-08.webp", alt: "Individual standing out from a crowd" },
  { src: "/infinity-canvas/canvas-09.webp", alt: "Collaborative professional workspace" },
  { src: "/infinity-canvas/canvas-10.webp", alt: "Friends sharing a meaningful conversation" },
  { src: "/infinity-canvas/canvas-11.webp", alt: "Creative team working together" },
  { src: "/infinity-canvas/canvas-12.webp", alt: "Together we can overcome anything" },
  { src: "/infinity-canvas/canvas-13.webp", alt: "Your vision, our mission" },
  { src: "/infinity-canvas/canvas-14.webp", alt: "Diverse hands joined in teamwork" },
  { src: "/infinity-canvas/canvas-15.webp", alt: "Colleagues connecting outdoors" },
  { src: "/infinity-canvas/canvas-16.webp", alt: "Think bigger" },
  { src: "/infinity-canvas/canvas-17.webp", alt: "Professional team collaborating" },
  { src: "/infinity-canvas/canvas-18.webp", alt: "Friends sharing a supportive group hug" },
  { src: "/infinity-canvas/canvas-19.webp", alt: "Community editorial collage" },
  { src: "/infinity-canvas/canvas-20.webp", alt: "People forming a connected circle" },
  { src: "/infinity-canvas/canvas-21.webp", alt: "Community embracing one another" },
  { src: "/infinity-canvas/canvas-22.webp", alt: "Professional presenting to a team" },
  { src: "/infinity-canvas/canvas-23.webp", alt: "Hands connected through a network" },
  { src: "/infinity-canvas/canvas-24.webp", alt: "In the right eyes you will be art" },
];

const identityPills = ["Personal", "Professional", "Communities"];

export default function WhatIsNewHubSection() {
  const [isCanvasActive, setIsCanvasActive] = useState(false);

  useEffect(() => {
    if (!isCanvasActive) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsCanvasActive(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isCanvasActive]);

  return (
    <section
      id="what-is-newhub"
      className="relative isolate overflow-hidden bg-transparent px-5 py-24 sm:px-7 sm:py-28 lg:px-10 lg:py-36"
    >
      <div className="relative z-10 mx-auto max-w-[1380px]">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.45 }}
          transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mb-12 max-w-3xl text-center sm:mb-14"
        >
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#7132C8]/15 bg-white/70 px-5 py-2.5 shadow-[0_10px_35px_rgba(78,48,140,0.08)] backdrop-blur-xl dark:border-white/10 dark:bg-white/[0.035] dark:shadow-none">
            <Sparkles className="h-3.5 w-3.5 text-[#F0199A]" />
            <span className="text-[10px] font-bold uppercase tracking-[0.28em] text-[#746f88] dark:text-white/45 sm:text-[11px]">
              What is NewHub?
            </span>
          </div>

          <h2 className="text-[34px] font-black leading-tight tracking-[-0.05em] text-[#17152a] dark:text-white sm:text-[43px] md:text-[52px]">
            Three sides. <span className={BRAND_GRADIENT_TEXT}>One complete you.</span>
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-sm leading-7 text-[#6d6a80] dark:text-white/48 sm:text-base">
            Explore personal expression, professional growth and communities in one free-moving visual space.
          </p>

          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            {identityPills.map((pill, index) => (
              <span
                key={pill}
                className={`rounded-full border px-4 py-2 text-xs font-semibold ${
                  index === 0
                    ? "border-[#F0199A]/20 bg-[#F0199A]/[0.07] text-[#C91B83] dark:text-pink-300"
                    : index === 1
                      ? "border-[#7132C8]/20 bg-[#7132C8]/[0.07] text-[#7132C8] dark:text-purple-300"
                      : "border-blue-500/20 bg-blue-500/[0.07] text-blue-600 dark:text-blue-300"
                }`}
              >
                {pill}
              </span>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 36, scale: 0.985 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.8, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
          className="relative overflow-hidden rounded-[28px] border border-[#7132C8]/15 bg-[#f7f6fb] shadow-[0_24px_70px_rgba(78,48,140,0.12)] dark:border-white/10 dark:bg-[#07040b] dark:shadow-[0_28px_80px_rgba(0,0,0,0.32)]"
        >
          <div
            className="relative h-[500px] overflow-hidden bg-[#f7f6fb] dark:bg-[#07040b] sm:h-[590px] lg:h-[660px]"
            onClick={() => {
              if (!isCanvasActive) setIsCanvasActive(true);
            }}
          >
            <InfiniteGallery
              width="100%"
              height="100%"
              images={newHubImages}
              density={2}
              imageWidth={180}
              imageHeight={220}
              rounded={3}
              dragSpeed={18}
              driftAmount={7}
              friction={11}
              backgroundColor="transparent"
              active={isCanvasActive}
            />

            {!isCanvasActive && (
              <button
                type="button"
                onClick={() => setIsCanvasActive(true)}
                className="absolute inset-0 z-20 flex cursor-pointer items-center justify-center bg-white/[0.08] px-5 backdrop-blur-[1px] transition-colors hover:bg-white/[0.02] dark:bg-black/10 dark:hover:bg-transparent"
                aria-label="Activate the Infinity Canvas"
              >
                <span className="flex max-w-sm flex-col items-center rounded-[22px] border border-[#7132C8]/15 bg-white/90 px-6 py-5 text-center shadow-[0_18px_55px_rgba(78,48,140,0.14)] backdrop-blur-xl dark:border-white/10 dark:bg-[#120b18]/90">
                  <MousePointerClick className="mb-3 h-6 w-6 text-[#7132C8] dark:text-purple-300" />
                  <span className="text-sm font-black text-[#211d2d] dark:text-white">
                    Click to explore
                  </span>
                  <span className="mt-2 text-xs leading-5 text-[#777181] dark:text-white/45">
                    After activation, drag freely and use the mouse wheel to move through the canvas.
                  </span>
                </span>
              </button>
            )}

            {isCanvasActive && (
              <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-3 p-4">
                <div className="pointer-events-none inline-flex flex-wrap items-center gap-3 rounded-full border border-white/10 bg-black/55 px-4 py-2.5 text-[10px] font-bold uppercase tracking-[0.12em] text-white/75 backdrop-blur-xl">
                  <span className="inline-flex items-center gap-1.5">
                    <Move className="h-3.5 w-3.5" /> Drag freely
                  </span>
                  <span className="h-3 w-px bg-white/20" />
                  <span className="inline-flex items-center gap-1.5">
                    <ZoomIn className="h-3.5 w-3.5" /> Scroll to zoom
                  </span>
                </div>

                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    setIsCanvasActive(false);
                  }}
                  className="pointer-events-auto inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/55 px-4 py-2.5 text-[10px] font-bold uppercase tracking-[0.12em] text-white/80 backdrop-blur-xl transition hover:bg-black/75 hover:text-white"
                  aria-label="Release the page scroll"
                >
                  <X className="h-3.5 w-3.5" /> Release scroll
                </button>
              </div>
            )}
          </div>
        </motion.div>

        <p className="mx-auto mt-6 max-w-2xl text-center text-xs leading-6 text-[#8b879d] dark:text-white/30 sm:text-sm">
          Click the canvas to activate it. Use “Release scroll” or press Esc to return to normal page scrolling.
        </p>
      </div>
    </section>
  );
}
