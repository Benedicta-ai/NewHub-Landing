NewHub clean Infinity Canvas replacement

Changes:
- Sparse, non-overlapping rectangular image tiles
- Slightly rounded edges
- Blank canvas background with no faded duplicate image layer
- Click to activate interaction
- Drag freely after activation
- Mouse wheel zooms only after activation
- Release Scroll button and Escape key restore normal page scrolling
- All 24 uploaded images remain available; visible density is reduced to 2

Replace:
src/components/landing/effects/InfiniteGallery.tsx
src/components/landing/WhatIsNewHubSection.tsx
