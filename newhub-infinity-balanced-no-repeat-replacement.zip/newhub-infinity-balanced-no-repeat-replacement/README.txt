NewHub Infinity Canvas — balanced no-repeat replacement

Changes:
- Keeps the full-width, borderless Infinity Canvas on the website background.
- Keeps click-to-activate, free dragging, wheel zoom, Release Scroll and Esc.
- Raises density from 5 to 8 so eight of the nine local grid positions are filled.
- Uses a balanced scale range (0.62–1.38) and smaller jitter to prevent collisions.
- Assigns images by global grid coordinates so neighbouring tiles never use the same image.
- Keeps a single solid zoom octave, so there is no faded duplicate image layer.

Replace:
1. src/components/landing/effects/InfiniteGallery.tsx
2. src/components/landing/WhatIsNewHubSection.tsx
