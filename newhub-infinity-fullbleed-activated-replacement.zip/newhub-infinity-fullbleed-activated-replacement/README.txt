NewHub full-bleed Infinity Canvas replacement

Changes:
- Removes the visible rounded box, border, shadow, and solid canvas panel.
- Uses the website's existing background directly.
- Makes the gallery span the full website width inside the What is NewHub section.
- Restores Originkit-style density and square image cards.
- Uses transparent canvas background and a single rendered octave, so there are no faded duplicate images behind the cards.
- Keeps click-to-activate interaction.
- Keeps Release scroll and Escape to return to normal page scrolling.
- Uses the existing 24 images in /public/infinity-canvas.
