NewHub Why NewHub — custom Tilted Card images

Included:
- public/tilted-cards/privacy-first.webp
- public/tilted-cards/meaningful-connections.webp
- public/tilted-cards/everything-in-one-place.webp
- src/components/landing/effects/TiltedCard.tsx
- src/components/landing/effects/TiltedCard.css
- src/components/landing/WhyNewHubSection.tsx

Image preparation:
- All three images are optimized WebP files.
- All three use the same 960 x 1000 ratio, matching the compact tilted-card shape.
- The main subjects were retained through focal cropping.
- All cards use the same responsive height: clamp(365px, 34vw, 390px).

Install Motion first from the workspace root:
pnpm --filter @workspace/matchglee-landing add motion

Copy the files into artifacts/matchglee-landing, preserving their paths.
Then run:
pnpm --filter @workspace/matchglee-landing run typecheck
pnpm --filter @workspace/matchglee-landing run build
