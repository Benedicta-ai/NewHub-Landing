NewHub minimal tilted cards

Replace these files:
- src/components/landing/effects/TiltedCard.tsx
- src/components/landing/effects/TiltedCard.css
- src/components/landing/WhyNewHubSection.tsx

This version keeps only the card title over each image. It removes icons,
numbers, tags, descriptions, arrows, and image gradients from the three cards.

The component imports from framer-motion, which is already used in the project,
so the separate motion package is not required for these files.
