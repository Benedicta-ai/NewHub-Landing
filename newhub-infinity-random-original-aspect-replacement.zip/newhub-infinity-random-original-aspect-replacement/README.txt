NewHub Infinity Canvas — Random Original-Aspect Replacement

Replace these files in the Replit project:

1. src/components/landing/effects/InfiniteGallery.tsx
2. src/components/landing/WhatIsNewHubSection.tsx

Changes:
- Random deterministic placement similar to the Originkit reference.
- Random deterministic card sizes.
- Every image keeps its original intrinsic aspect ratio.
- Portrait images remain portrait; landscape images remain landscape; square images remain square.
- No cropped square variants.
- No blurred image backdrop inside cards.
- Adjacent images do not repeat.
- Full-width transparent canvas remains on the website background.
- Cards fade and blur before reaching the canvas edge.
- Click to activate, drag, wheel zoom, Release Scroll and Escape are preserved.

The 24 images must already exist under:
public/infinity-canvas/canvas-01.webp ... canvas-24.webp
