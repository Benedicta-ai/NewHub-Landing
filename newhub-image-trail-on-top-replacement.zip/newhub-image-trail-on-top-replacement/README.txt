NewHub Image Trail - On Top Replacement

This replacement changes only the Image Trail stacking order.
The trail now appears above the Built for All heading and cards.

The layer remains pointer-events: none, so buttons, hover states, and cards remain usable.

Replace:
src/components/landing/effects/ImageTrail.css
