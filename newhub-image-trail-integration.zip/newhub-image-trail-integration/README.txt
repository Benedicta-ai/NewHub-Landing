NewHub Image Trail Integration

Contents:
- public/image-trail/trail-01.webp through trail-09.webp
- src/components/landing/effects/ImageTrail.tsx
- src/components/landing/effects/ImageTrail.css
- src/components/landing/BuiltForAllSection.tsx

Install GSAP:
pnpm --filter @workspace/matchglee-landing add gsap

The trail uses Variant 1 behaviour with an 80px movement threshold.
It is enabled only for desktop fine-pointer devices and is disabled for reduced-motion users.
The trail layer has pointer-events disabled, so card hover and normal scrolling remain unaffected.
