NewHub Infinity Canvas — soft-edge/full-image replacement

Files:
- src/components/landing/effects/InfiniteGallery.tsx
- src/components/landing/WhatIsNewHubSection.tsx

Changes:
- Full image content uses object-fit: contain, so text and people are not cropped.
- A blurred copy fills each card behind the complete image.
- Whole cards fade and blur before touching the canvas edges.
- No harsh half-image clipping at the top, bottom, left or right.
- Existing transparent/full-width canvas, density, no-repeat distribution,
  click-to-activate, free drag, scroll-to-zoom, Release Scroll and Esc are retained.
