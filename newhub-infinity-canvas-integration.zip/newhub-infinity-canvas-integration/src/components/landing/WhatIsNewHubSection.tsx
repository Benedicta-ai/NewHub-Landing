import { motion } from "framer-motion";
import {
  Move,
  Sparkles,
  ZoomIn,
} from "lucide-react";
import { BRAND_GRADIENT_TEXT } from "@/lib/brand";
import InfiniteGallery from "./effects/InfiniteGallery";

import personalImage from "@/assets/newhub_carousel_assets/09_personal.png";
import professionalImage from "@/assets/newhub_carousel_assets/10_professional.png";
import communitiesImage from "@/assets/newhub_carousel_assets/11_communities_alt.png";
import dualPersonalitiesImage from "@/assets/newhub_carousel_assets/01_dual_personalities.png";
import professionalIdentityImage from "@/assets/newhub_carousel_assets/04_professional_identity.png";
import personalIdentityImage from "@/assets/newhub_carousel_assets/05_personal_identity.png";
import careerGrowthImage from "@/assets/newhub_carousel_assets/07_career_growth.png";
import meaningfulRelationshipsImage from "@/assets/newhub_carousel_assets/08_meaningful_relationships.png";
import privacyImage from "@/assets/newhub_carousel_assets/12_secure_private.png";
import meaningfulConnectionsImage from "@/assets/newhub_carousel_assets/13_meaningful_connections.png";

const newHubImages = [
  {
    src: personalImage,
    alt: "Personal identity on NewHub",
  },
  {
    src: professionalImage,
    alt: "Professional identity on NewHub",
  },
  {
    src: communitiesImage,
    alt: "Communities on NewHub",
  },
  {
    src: dualPersonalitiesImage,
    alt: "Personal and professional identities together",
  },
  {
    src: professionalIdentityImage,
    alt: "Career profile and professional growth",
  },
  {
    src: personalIdentityImage,
    alt: "Personal interests and authentic expression",
  },
  {
    src: careerGrowthImage,
    alt: "Career development and opportunities",
  },
  {
    src: meaningfulRelationshipsImage,
    alt: "Meaningful relationships and shared values",
  },
  {
    src: privacyImage,
    alt: "Privacy and identity control",
  },
  {
    src: meaningfulConnectionsImage,
    alt: "Authentic connections on NewHub",
  },
];

const identityPills = [
  "Personal",
  "Professional",
  "Communities",
];

export default function WhatIsNewHubSection() {
  return (
    <section
      id="what-is-newhub"
      className="
        relative
        isolate
        overflow-hidden
        bg-transparent
        px-5
        py-24
        sm:px-7
        sm:py-28
        lg:px-10
        lg:py-36
      "
    >
      <div
        aria-hidden="true"
        className="
          pointer-events-none
          absolute
          left-1/2
          top-[58%]
          h-[760px]
          w-[min(1180px,115vw)]
          -translate-x-1/2
          -translate-y-1/2
          rounded-full
          bg-[#7132C8]/12
          blur-[190px]
          dark:bg-[#7132C8]/[0.08]
        "
      />

      <div
        aria-hidden="true"
        className="
          pointer-events-none
          absolute
          left-[6%]
          top-[34%]
          h-72
          w-72
          rounded-full
          bg-[#F0199A]/10
          blur-[120px]
          dark:bg-[#F0199A]/[0.06]
        "
      />

      <div
        aria-hidden="true"
        className="
          pointer-events-none
          absolute
          bottom-[8%]
          right-[5%]
          h-72
          w-72
          rounded-full
          bg-blue-400/10
          blur-[120px]
          dark:bg-blue-500/[0.06]
        "
      />

      <div className="relative z-10 mx-auto max-w-[1380px]">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.45 }}
          transition={{
            duration: 0.75,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="mx-auto mb-12 max-w-3xl text-center sm:mb-14"
        >
          <div
            className="
              mb-5
              inline-flex
              items-center
              gap-2
              rounded-full
              border
              border-[#7132C8]/15
              bg-white/65
              px-5
              py-2.5
              shadow-[0_10px_35px_rgba(78,48,140,0.08)]
              backdrop-blur-xl
              dark:border-white/10
              dark:bg-white/[0.035]
              dark:shadow-none
            "
          >
            <Sparkles className="h-3.5 w-3.5 text-[#F0199A]" />

            <span
              className="
                text-[10px]
                font-bold
                uppercase
                tracking-[0.28em]
                text-[#746f88]
                dark:text-white/45
                sm:text-[11px]
              "
            >
              What is NewHub?
            </span>
          </div>

          <h2
            className="
              text-[34px]
              font-black
              leading-tight
              tracking-[-0.05em]
              text-[#17152a]
              dark:text-white
              sm:text-[43px]
              md:text-[52px]
            "
          >
            Three sides. {" "}
            <span className={BRAND_GRADIENT_TEXT}>
              One complete you.
            </span>
          </h2>

          <p
            className="
              mx-auto
              mt-5
              max-w-2xl
              text-sm
              leading-7
              text-[#6d6a80]
              dark:text-white/48
              sm:text-base
            "
          >
            Explore how your personal world, professional direction and
            communities connect inside one continuously evolving identity.
          </p>

          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            {identityPills.map((pill, index) => (
              <span
                key={pill}
                className={`
                  rounded-full
                  border
                  px-4
                  py-2
                  text-xs
                  font-semibold
                  backdrop-blur-xl
                  ${
                    index === 0
                      ? "border-[#F0199A]/20 bg-[#F0199A]/[0.07] text-[#C91B83] dark:text-pink-300"
                      : index === 1
                        ? "border-[#7132C8]/20 bg-[#7132C8]/[0.07] text-[#7132C8] dark:text-purple-300"
                        : "border-blue-500/20 bg-blue-500/[0.07] text-blue-600 dark:text-blue-300"
                  }
                `}
              >
                {pill}
              </span>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.98 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{
            duration: 0.85,
            delay: 0.08,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="
            relative
            overflow-hidden
            rounded-[34px]
            border
            border-[#7132C8]/15
            bg-white/65
            p-2.5
            shadow-[0_32px_100px_rgba(78,48,140,0.15)]
            backdrop-blur-2xl
            dark:border-white/10
            dark:bg-white/[0.04]
            dark:shadow-[0_34px_100px_rgba(0,0,0,0.34)]
            sm:p-3
          "
        >
          <div
            aria-hidden="true"
            className="
              pointer-events-none
              absolute
              inset-x-[15%]
              top-[-6rem]
              h-56
              rounded-full
              bg-[#7132C8]/15
              blur-[85px]
              dark:bg-[#7132C8]/10
            "
          />

          <div
            className="
              relative
              h-[520px]
              overflow-hidden
              rounded-[27px]
              bg-[linear-gradient(135deg,#fff_0%,#faf7ff_48%,#f0e9ff_100%)]
              dark:bg-[linear-gradient(135deg,#0b0318_0%,#110522_48%,#090210_100%)]
              sm:h-[620px]
              lg:h-[720px]
            "
          >
            <InfiniteGallery
              width="100%"
              height="100%"
              images={newHubImages}
              density={3}
              imageWidth={220}
              imageHeight={280}
              rounded={14}
              dragSpeed={7}
              driftAmount={5}
              friction={14}
              backgroundColor="transparent"
            />

            <div
              aria-hidden="true"
              className="
                pointer-events-none
                absolute
                inset-0
                bg-[radial-gradient(circle_at_center,transparent_45%,rgba(255,255,255,0.48)_100%)]
                dark:bg-[radial-gradient(circle_at_center,transparent_45%,rgba(5,1,12,0.55)_100%)]
              "
            />

            <div
              className="
                pointer-events-none
                absolute
                inset-x-0
                bottom-0
                flex
                justify-center
                bg-gradient-to-t
                from-white/85
                via-white/40
                to-transparent
                px-4
                pb-5
                pt-16
                dark:from-[#090210]/90
                dark:via-[#090210]/45
              "
            >
              <div
                className="
                  flex
                  flex-wrap
                  items-center
                  justify-center
                  gap-3
                  rounded-full
                  border
                  border-[#7132C8]/15
                  bg-white/75
                  px-4
                  py-2.5
                  text-[10px]
                  font-bold
                  uppercase
                  tracking-[0.14em]
                  text-[#716c82]
                  shadow-[0_10px_30px_rgba(78,48,140,0.1)]
                  backdrop-blur-xl
                  dark:border-white/10
                  dark:bg-black/30
                  dark:text-white/50
                "
              >
                <span className="inline-flex items-center gap-1.5">
                  <Move className="h-3.5 w-3.5" />
                  Drag to explore
                </span>

                <span className="h-3 w-px bg-[#7132C8]/20 dark:bg-white/10" />

                <span className="hidden items-center gap-1.5 sm:inline-flex">
                  <ZoomIn className="h-3.5 w-3.5" />
                  Ctrl or Cmd + scroll to zoom
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.8 }}
          transition={{ duration: 0.65, delay: 0.25 }}
          className="
            mx-auto
            mt-8
            max-w-2xl
            text-center
            text-xs
            leading-6
            text-[#8b879d]
            dark:text-white/30
            sm:text-sm
          "
        >
          Move through the canvas to see every side of NewHub as part of one
          connected experience.
        </motion.p>
      </div>
    </section>
  );
}
