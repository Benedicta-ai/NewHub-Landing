NewHub Infinity Canvas integration

Files:
1. src/components/landing/effects/InfiniteGallery.tsx
2. src/components/landing/WhatIsNewHubSection.tsx

The InfiniteGallery source was adapted for NewHub:
- normal page scrolling is preserved
- Ctrl/Cmd + wheel zooms the canvas
- touch devices keep vertical scrolling
- minimum width was removed for mobile
- animation pauses while the section is off-screen
- reduced-motion users receive a static canvas

Copy both files into the matching paths in the Replit project, then run:
pnpm --filter @workspace/matchglee-landing run typecheck
pnpm --filter @workspace/matchglee-landing run build
