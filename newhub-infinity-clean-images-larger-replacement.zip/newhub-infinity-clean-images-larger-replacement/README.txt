NewHub Infinity Canvas — clean original images + larger tiles

Changes only:
- keeps each source image in its original aspect ratio
- removes per-tile grey/letterbox background
- uses exact intrinsic dimensions for all 24 images
- increases the base image size from 190 to 220
- keeps existing distribution, drag, zoom, activation and edge fade behavior
